1. 學號：B04901056

2. 姓名：張承洋

3. 使用之程式語言：< C++ >

4. 使用之編譯器：< GNU g++ >

5. 檔案壓縮方式: <zip -r b04901056_p3_v1.zip b04901056_p3_v1>

6. 各檔案說明： 
	src/router.cpp: 實作程式碼  
	report.doc：程式報告  
	router : Executable binaries 
	
7. 編譯方式說明： 
	cd src
	g++ router.cpp -o ../router 
	       
8. 執行、使用方式說明：
  
	編譯完成後，在檔案目錄下會產生 router 執行檔
    
	執行檔的命令格式為：
  ./router <input file name> <output file name>
   
	例如：要對 gr4x4.in 執行輸出 gr4x4.out 
  
	則在命令提示下鍵入
 ./router gr4x4.in gr4x4.out  


9. 執行結果說明（說明執行結果的觀看方法，及解釋各項數據等）：
詳見 report.doc  							
       
